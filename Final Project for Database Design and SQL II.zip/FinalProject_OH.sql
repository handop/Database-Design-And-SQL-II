-- --------------------------------------------------------------------------------
-- Name: Oliver Hand
-- Class: IT-112
-- Abstract: Final Project
-- --------------------------------------------------------------------------------

-- --------------------------------------------------------------------------------
-- Options
-- --------------------------------------------------------------------------------
USE dbSQL1;     -- Get out of the master database
SET NOCOUNT ON; -- Report only errors

-- --------------------------------------------------------------------------------
-- Drop Tables
-- --------------------------------------------------------------------------------
IF OBJECT_ID('TDrugKits')				IS NOT NULL DROP TABLE TDrugKits
IF OBJECT_ID('TVisits')					IS NOT NULL DROP TABLE TVisits
IF OBJECT_ID('TPatients')				IS NOT NULL DROP TABLE TPatients
IF OBJECT_ID('TVisitTypes')				IS NOT NULL DROP TABLE TVisitTypes
IF OBJECT_ID('TRandomCodes')			IS NOT NULL DROP TABLE TRandomCodes
IF OBJECT_ID('TWithdrawReasons')		IS NOT NULL DROP TABLE TWithdrawReasons
IF OBJECT_ID('TSites')					IS NOT NULL DROP TABLE TSites
IF OBJECT_ID('TStates')					IS NOT NULL DROP TABLE TStates
IF OBJECT_ID('TGenders')				IS NOT NULL DROP TABLE TGenders
IF OBJECT_ID('TStudies')				IS NOT NULL DROP TABLE TStudies

-- --------------------------------------------------------------------------------
-- Drop Views
-- --------------------------------------------------------------------------------
IF OBJECT_ID('VSitePatients')					IS NOT NULL DROP VIEW VSitePatients
IF OBJECT_ID('VRandomizedPatients')				IS NOT NULL DROP VIEW VRandomizedPatients
IF OBJECT_ID('VStudyTwoRandomizedPatients')		IS NOT NULL DROP VIEW VStudyTwoRandomizedPatients
IF OBJECT_ID('VStudyOneNextCode')				IS NOT NULL DROP VIEW VStudyOneNextCode
IF OBJECT_ID('VStudyTwoNextPlaceboCode')		IS NOT NULL DROP VIEW VStudyTwoNextPlaceboCode
IF OBJECT_ID('VStudyTwoNextActiveCode')			IS NOT NULL DROP VIEW VStudyTwoNextActiveCode
IF OBJECT_ID('VStudyOneAvailableDrugKits')		IS NOT NULL DROP VIEW VStudyOneAvailableDrugKits
IF OBJECT_ID('VStudyTwoAvailableDrugKits')		IS NOT NULL DROP VIEW VStudyTwoAvailableDrugKits
IF OBJECT_ID('VWithdrawnPatients')				IS NOT NULL DROP VIEW VWithdrawnPatients
IF OBJECT_ID('VVisits')							IS NOT NULL DROP VIEW VVisits
IF OBJECT_ID('VRandomizedPlacebo')				IS NOT NULL DROP VIEW VRandomizedPlacebo
IF OBJECT_ID('VRandomizedActive')				IS NOT NULL DROP VIEW VRandomizedActive
IF OBJECT_ID('VRandomCodes')					IS NOT NULL DROP VIEW VRandomCodes
-- --------------------------------------------------------------------------------
-- Drop Stored Procedures
-- --------------------------------------------------------------------------------
IF OBJECT_ID('uspAddPatient')				IS NOT NULL DROP PROCEDURE uspAddPatient
IF OBJECT_ID('uspCreatePatientNumber')		IS NOT NULL DROP PROCEDURE uspCreatePatientNumber
IF OBJECT_ID('uspScreenPatient')			IS NOT NULL DROP PROCEDURE uspScreenPatient
IF OBJECT_ID('uspWithdrawPatient')			IS NOT NULL DROP PROCEDURE uspWithdrawPatient
IF OBJECT_ID('uspRandomizedNumber')			IS NOT NULL DROP PROCEDURE uspRandomizedNumber
IF OBJECT_ID('uspRandomizePatient')			IS NOT NULL DROP PROCEDURE uspRandomizePatient
IF OBJECT_ID('uspAssignDrugKit')			IS NOT NULL DROP PROCEDURE uspAssignDrugKit
-- --------------------------------------------------------------------------------
-- Step #1.1: Create Tables
-- --------------------------------------------------------------------------------
CREATE TABLE TStudies
(
	intStudyID		INTEGER	IDENTITY	NOT NULL
   ,strStudyDesc	VARCHAR(250)	    NOT NULL
   ,CONSTRAINT TStudies_PK PRIMARY KEY (intStudyID)
)

CREATE TABLE TSites
(
	intSiteID		INTEGER IDENTITY		NOT NULL
   ,intSiteNumber	INTEGER					NOT NULL
   ,intStudyID		INTEGER					NOT NULL
   ,strName			VARCHAR(250)			NOT NULL
   ,strAddress		VARCHAR(250)			NOT NULL
   ,strCity			VARCHAR(250)			NOT NULL
   ,intStateID		INTEGER					NOT NULL
   ,strZip			VARCHAR(250)			NOT NULL
   ,strPhoneNumber	VARCHAR(250)			NOT NULL
   CONSTRAINT TSites_PK PRIMARY KEY (intSiteID)
)

CREATE TABLE TPatients
(
	intPatientID		INTEGER IDENTITY	NOT NULL
   ,intPatientNumber	INTEGER				NOT NULL
   ,intSiteID			INTEGER				NOT NULL
   ,dtDateofBirth		DATE				NOT NULL
   ,intGenderID			INTEGER				NOT NULL
   ,intWeight			INTEGER				NOT NULL
   ,intRandomCodeID		INTEGER
   ,CONSTRAINT TPatients_PK PRIMARY KEY (intPatientID)
)

CREATE TABLE TVisitTypes
(
	intVisitTypeID		INTEGER IDENTITY	NOT NULL
   ,strVisitDesc		VARCHAR(250)		NOT NULL
   CONSTRAINT TVisitTypes_PK PRIMARY KEY (intVisitTypeID)
)

CREATE TABLE TVisits
(
	intVisitID				INTEGER IDENTITY	NOT NULL
   ,intPatientID			INTEGER				NOT NULL
   ,dtmDateofVisit			DATE				NOT NULL					
   ,intVisitTypeID			INTEGER				NOT NULL
   ,intWithdrawReasonID		INTEGER
   CONSTRAINT TVisits_PK PRIMARY KEY (intVisitID)
)

CREATE TABLE TRandomCodes
(
	intRandomCodeID		INTEGER IDENTITY	NOT NULL
   ,intRandomCode		INTEGER				NOT NULL
   ,intStudyID			INTEGER				NOT NULL
   ,strTreatment		VARCHAR(250)		NOT NULL
   ,blnAvailable		VARCHAR(1)			NOT NULL
   CONSTRAINT TRandomCodes_PK PRIMARY KEY (intRandomCodeID)
)

CREATE TABLE TDrugKits
(
	intDrugKitID		INTEGER IDENTITY	NOT NULL
   ,intDrugKitNumber	INTEGER				NOT NULL
   ,intSiteID			INTEGER				NOT NULL
   ,strTreatment		VARCHAR(1)			NOT NULL
   ,intVisitID			INTEGER
   ,CONSTRAINT TDrugKits_PK	PRIMARY KEY (intDrugKitID)
)

CREATE TABLE TWithdrawReasons
(
	intWithdrawReasonID		INTEGER IDENTITY	NOT NULL
   ,strWithdrawDesc			VARCHAR(1000)		NOT NULL
   ,CONSTRAINT TWithdrawReasons_PK PRIMARY KEY (intWithdrawReasonID)
)

CREATE TABLE TGenders
(
	intGenderID		INTEGER IDENTITY	NOT NULL
   ,strGender		VARCHAR(250)		NOT NULL
   ,CONSTRAINT TGenders_PK PRIMARY KEY (intGenderID)
)

CREATE TABLE TStates
(
	intStateID		INTEGER IDENTITY	NOT NULL
   ,strState		VARCHAR(250)		NOT NULL
   ,CONSTRAINT TStates_PK PRIMARY KEY (intStateID)
)

-- --------------------------------------------------------------------------------
-- Step #1.2: Identify and Create Foreign Keys
-- --------------------------------------------------------------------------------
--
-- #	Child					Parent					Column(s)
-- -	-----					------					---------
-- 1)	TSites					TStates					intStateID
-- 2)	TSites					TStudies				intStudyID
-- 3)	TPatients				TSites					intSiteID
-- 4)	TPatients				TGenders				intGenderID
-- 5)	TPatients				TRandomCodes			intRandomCodeID
-- 6)	TVisits					TPatients				intPatientID
-- 7)	TVisits					TVisitTypes				intVisitTypeID
-- 8)	TVisits					TWithdrawReasons		intWithdrawReasonID
-- 9)	TRandomCodes			TStudies				intStudyID
-- 10)	TDrugKits				TSites					intSiteID
-- 11)	TDrugKits				TVisits					intVisitID

-- 1)
ALTER TABLE TSites ADD CONSTRAINT TSites_TStates_FK
FOREIGN KEY (intStateID) REFERENCES TStates (intStateID)

-- 2)
ALTER TABLE TSites ADD CONSTRAINT TSites_TStudies_FK
FOREIGN KEY (intStudyID) REFERENCES TStudies (intStudyID)

-- 3)
ALTER TABLE TPatients ADD CONSTRAINT TPatients_TSites_FK
FOREIGN KEY (intSiteID) REFERENCES TSites (intSiteID)

-- 4)
ALTER TABLE TPatients ADD CONSTRAINT TPatients_TGenders_FK
FOREIGN KEY (intGenderID) REFERENCES TGenders (intGenderID)

-- 5)
ALTER TABLE TPatients ADD CONSTRAINT TPatients_TRandomCodes_FK
FOREIGN KEY (intRandomCodeID) REFERENCES TRandomCodes (intRandomCodeID)

-- 6)
ALTER TABLE TVisits ADD CONSTRAINT TVisits_TPatients_FK
FOREIGN KEY (intPatientID) REFERENCES TPatients (intPatientID)

-- 7)
ALTER TABLE TVisits ADD CONSTRAINT TVisits_TVisitTypes_FK
FOREIGN KEY (intVisitTypeID) REFERENCES TVisitTypes (intVisitTypeID)

-- 8)
ALTER TABLE TVisits ADD CONSTRAINT TVisits_TWithdrawReasons_FK
FOREIGN KEY (intWithdrawReasonID) REFERENCES TWithdrawReasons (intWithdrawReasonID)

-- 9)
ALTER TABLE TRandomCodes ADD CONSTRAINT TRandomCodes_TStudies_FK
FOREIGN KEY (intStudyID) REFERENCES TStudies (intStudyID)

-- 10)
ALTER TABLE TDrugKits ADD CONSTRAINT TDrugKits_TSites_FK
FOREIGN KEY (intSiteID) REFERENCES TSites (intSiteID)

-- 11)
ALTER TABLE TDrugKits ADD CONSTRAINT TDrugKits_TVisits_FK
FOREIGN KEY (intVisitID) REFERENCES TVisits (intVisitID)

-- --------------------------------------------------------------------------------
-- Step #1.3: Add data
-- --------------------------------------------------------------------------------

INSERT INTO TStudies(strStudyDesc)
VALUES	('Study 12345')
	   ,('Study 54321')

INSERT INTO TGenders(strGender)
VALUES  ('Male')
	   ,('Female')

INSERT INTO TStates(strState)
VALUES	('Ohio')
	   ,('Kentucky')
	   ,('Indiana')
	   ,('New Jersey')
	   ,('Virginia')
	   ,('Georia')
	   ,('Iowa')

INSERT INTO TVisitTypes (strVisitDesc)
VALUES	('Screening')
	   ,('Randomization')
	   ,('Withdrawel')

INSERT INTO TSites(intSiteNumber, intStudyID, strName, strAddress, strCity, intStateID, strZip, strPhoneNumber)
VALUES	(101, 1, 'Dr. Stan Heinrich', '123 E. Main St', 'Atlanta', 5, '25869', '1234567890')
	   ,(111, 1, 'Mercy Hospital', '3456 Elmhurst Rd.',	'Secaucus',	4, '32659',	'5013629564')
	   ,(121, 1, 'St. Elizabeth Hospital', '976 Jackson Way', 'Ft. Thomas', 2, '41258', '3026521478')
	   ,(501, 2, 'Dr. Robert Adler', '9087 W. Maple Ave.', 'Cedar Rapids', 7, '42365', '6149652574')
	   ,(511, 2, 'Dr. Tim Schmitz', '4539 Helena Run', 'Mason', 1, '45040', '5136987462')
	   ,(521, 2, 'Dr. Lawrence Snell', '9201 NW. Washington Blvd.', 'Bristol', 5, '20163', '3876510249')

INSERT INTO TWithdrawReasons
VALUES	('Patient Withdrew Consent')
	   ,('Adverse Event')
	   ,('Health Issue - Related to Study')
	   ,('Health Issue - Unrelated to Study')
	   ,('Personal Reason')
	   ,('Completed the Study')

INSERT INTO TRandomCodes(intRandomCode, intStudyID, strTreatment, blnAvailable)
VALUES	(1000, 1, 'A', 'T')
	   ,(1001, 1, 'P', 'T')
	   ,(1002, 1, 'A', 'T')
	   ,(1003, 1, 'P', 'T')
	   ,(1004, 1, 'P', 'T')
	   ,(1005, 1, 'A', 'T')
	   ,(1006, 1, 'A', 'T')
	   ,(1007, 1, 'P', 'T')
	   ,(1008, 1, 'A', 'T')
	   ,(1009, 1, 'P', 'T')
	   ,(1010, 1, 'P', 'T')
	   ,(1011, 1, 'A', 'T')
	   ,(1012, 1, 'P', 'T')
	   ,(1013, 1, 'A', 'T')
	   ,(1014, 1, 'A', 'T')
	   ,(1015, 1, 'A', 'T')
	   ,(1016, 1, 'P', 'T')
	   ,(1017, 1, 'P', 'T')
	   ,(1018, 1, 'A', 'T')
	   ,(1019, 1, 'P', 'T')
	   ,(5000, 2, 'A', 'T')
	   ,(5001, 2, 'A', 'T')
	   ,(5002, 2, 'A', 'T')
	   ,(5003, 2, 'A', 'T')
	   ,(5004, 2, 'A', 'T')
	   ,(5005, 2, 'A', 'T')
	   ,(5006, 2, 'A', 'T')
	   ,(5007, 2, 'A', 'T')
	   ,(5008, 2, 'A', 'T')
	   ,(5009, 2, 'A', 'T')
	   ,(5010, 2, 'P', 'T')
	   ,(5011, 2, 'P', 'T')
	   ,(5012, 2, 'P', 'T')
	   ,(5013, 2, 'P', 'T')
	   ,(5014, 2, 'P', 'T')
	   ,(5015, 2, 'P', 'T')
	   ,(5016, 2, 'P', 'T')
	   ,(5017, 2, 'P', 'T')
	   ,(5018, 2, 'P', 'T')
	   ,(5019, 2, 'P', 'T')

INSERT INTO TDrugKits (intDrugKitNumber, intSiteID, strTreatment)
VALUES	(10000,	1, 'A')
	   ,(10001,	1, 'A')
	   ,(10002,	1, 'A')
	   ,(10003,	1, 'P')
	   ,(10004,	1, 'P')
	   ,(10005,	1, 'P')
	   ,(10006,	2, 'A')
	   ,(10007,	2, 'A')
	   ,(10008,	2, 'A')
	   ,(10009,	2, 'P')
	   ,(10010,	2, 'P')
	   ,(10011,	2, 'P')
	   ,(10012,	3, 'A')
	   ,(10013,	3, 'A')
	   ,(10014,	3, 'A')
	   ,(10015,	3, 'P')
	   ,(10016,	3, 'P')
	   ,(10017,	3, 'P')
	   ,(10018,	4, 'A')
	   ,(10019,	4, 'A')
	   ,(10020,	4, 'A')
	   ,(10021,	4, 'P')
	   ,(10022,	4, 'P')
	   ,(10023,	4, 'P')
	   ,(10024,	5, 'A')
	   ,(10025,	5, 'A')
	   ,(10026,	5, 'A')
	   ,(10027,	5, 'P')
	   ,(10028,	5, 'P')
	   ,(10029,	5, 'P')
	   ,(10030,	6, 'A')
	   ,(10031,	6, 'A')
	   ,(10032,	6, 'A')
	   ,(10033,	6, 'P')
	   ,(10034,	6, 'P')
	   ,(10035,	6, 'P')
GO
-- --------------------------------------------------------------------------------
-- Step #2: Creating VPatients
-- --------------------------------------------------------------------------------
CREATE VIEW VSitePatients
AS
	SELECT TS.intStudyID, TSt.strStudyDesc, TS.intSiteID, TS.intSiteNumber, TS.strName, TP.intPatientID, TP.intPatientNumber, TP.intRandomCodeID
	
	FROM TPatients AS TP INNER JOIN TSites AS TS
	ON TP.intSiteID = TS.intSiteID
	INNER JOIN TStudies AS TSt
	ON TSt.intStudyID = TS.intStudyID
GO

-- --------------------------------------------------------------------------------
-- Step #3.1: Creating VRandomizedPatients
-- --------------------------------------------------------------------------------

CREATE VIEW VRandomizedPatients
AS
	SELECT TP.intPatientID, TP.intPatientNumber, TP.intRandomCodeID, TR.intRandomCode, TS.intSiteNumber, TS.intStudyID, TS.strName, TR.strTreatment
	
	FROM TPatients AS TP INNER JOIN TSites AS TS
	ON TP.intSiteID = TS.intSiteID
	INNER JOIN TRandomCodes AS TR
	ON TR.intRandomCodeID = TP.intRandomCodeID

	WHERE TP.intRandomCodeID IS NOT NULL
GO

-- --------------------------------------------------------------------------------
-- Step #4.1: Creating VStudyOneNextCode
-- --------------------------------------------------------------------------------

CREATE VIEW VStudyOneNextCode
AS
	SELECT MIN(intRandomCodeID) AS Next_Code_Study_One
	FROM TRandomCodes
	WHERE intStudyID = 1
	AND blnAvailable = 'T'
GO

-- --------------------------------------------------------------------------------
-- Step #4.2: Creating VStudyTwoNextplaceboCode
-- --------------------------------------------------------------------------------

CREATE VIEW VStudyTwoNextPlaceboCode
AS
	SELECT MIN(intRandomCodeID) AS Next_Placebo_Code_Study_Two
	FROM TRandomCodes
	WHERE intStudyID = 2
	AND blnAvailable = 'T'
	AND strTreatment = 'P'
GO

-- --------------------------------------------------------------------------------
-- Step #4.3: Creating VStudyTwoNextActiveCode
-- --------------------------------------------------------------------------------

CREATE VIEW VStudyTwoNextActiveCode
AS
	SELECT MIN(intRandomCodeID) AS Next_Active_Code_Study_Two
	FROM TRandomCodes
	WHERE intStudyID = 2
	AND blnAvailable = 'T'
	AND strTreatment = 'A'
GO

-- --------------------------------------------------------------------------------
-- Step #5.1: Creating VStudyOneAvailableDrugKits
-- --------------------------------------------------------------------------------

CREATE VIEW VStudyOneAvailableDrugKits
AS
	SELECT TS.intSiteNumber, TS.strName, TD.intDrugKitID, TD.intVisitID, TD.strTreatment
	FROM TDrugKits AS TD INNER JOIN TSites AS TS
	ON TD.intSiteID = TS.intSiteID 
	WHERE intStudyID = 1
	AND TD.intVisitID IS NULL
GO

-- --------------------------------------------------------------------------------
-- Step #5.2: Creating VStudyTwoAvailableDrugKits
-- --------------------------------------------------------------------------------

CREATE VIEW VStudyTwoAvailableDrugKits
AS
	SELECT TS.intSiteNumber, TS.strName, TD.intDrugKitID, TD.intVisitID, TD.strTreatment
	FROM TDrugKits AS TD INNER JOIN TSites AS TS
	ON TD.intSiteID = TS.intSiteID 
	WHERE intStudyID = 2
	AND TD.intVisitID IS NULL
GO

-- --------------------------------------------------------------------------------
-- Step #6: Creating VWithdrawnPatients
-- --------------------------------------------------------------------------------

CREATE VIEW VWithdrawnPatients
AS
	SELECT TP.intPatientID, TP.intPatientNumber, TS.intSiteNumber, TS.strName, TV.dtmDateofVisit, TW.strWithdrawDesc
	FROM TPatients AS TP INNER JOIN TSites AS TS
	ON TP.intSiteID = TS.intSiteID
	INNER JOIN TVisits AS TV
	ON TV.intPatientID = TP.intPatientID
	INNER JOIN TWithdrawReasons AS TW
	ON TW.intWithdrawReasonID = TV.intWithdrawReasonID
GO

-- --------------------------------------------------------------------------------
-- Step #7.1: Creating uspCreatePatientNumber
-- --------------------------------------------------------------------------------
CREATE PROCEDURE uspCreatePatientNumber
	@intSiteID			AS INTEGER
   ,@intPatientNumber	AS INTEGER OUTPUT
AS
BEGIN
	DECLARE @intPatientPlace	AS INTEGER 
	SET @intPatientPlace = (SELECT FORMAT(COUNT(intPatientID) + 1, '000') AS Total_Site_Patients
							FROM TPatients
							WHERE intSiteID = @intSiteID)

	SET @intPatientNumber = (SELECT (intSiteNumber * 1000) + @intPatientPlace
							 FROM TSites
							 WHERE intSiteID = @intSiteID)
END
GO

-- --------------------------------------------------------------------------------
-- Step #7.2: Creating uspAddPatient
-- --------------------------------------------------------------------------------

CREATE PROCEDURE uspAddPatient
	@intPatientNumber	AS INTEGER OUTPUT
   ,@intSiteID			AS INTEGER
   ,@dtmDateofBirth		AS DATE
   ,@intGenderID		AS INTEGER
   ,@intWeight			AS INTEGER
AS
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error
BEGIN TRANSACTION
	EXECUTE uspCreatePatientNumber @intSiteID, @intPatientNumber OUTPUT
	INSERT INTO TPatients (intPatientNumber, intSiteID, dtDateofBirth, intGenderID, intWeight)
	VALUES (@intPatientNumber, @intSiteID, @dtmDateofBirth, @intGenderID, @intWeight)
COMMIT TRANSACTION
GO

-- --------------------------------------------------------------------------------
-- Step #7.3: Creating VVisits
-- --------------------------------------------------------------------------------
CREATE VIEW VVisits
AS
	SELECT TV.intVisitID, TV.intPatientID, TP.intPatientNumber, TV.dtmDateofVisit, TV.intVisitTypeID, TVt.strVisitDesc, TW.strWithdrawDesc
	FROM TVisits AS TV INNER JOIN TVisitTypes AS TVt
	ON TV.intVisitTypeID = TVt.intVisitTypeID
	LEFT JOIN TWithdrawReasons AS TW
	ON TV.intWithdrawReasonID = TW.intWithdrawReasonID
	INNER JOIN TPatients AS TP
	ON TP.intPatientid = tv.intPatientID
GO

-- --------------------------------------------------------------------------------
-- Step #7.4: Creating VRandomizedPlacebo
-- --------------------------------------------------------------------------------
CREATE VIEW VRandomizedPlacebo
AS
	SELECT COUNT(intRandomCodeID) AS NumberPlaceboCodes
	FROM VRandomizedPatients
	WHERE intStudyID = 2
	AND strTreatment = 'P'
GO

-- --------------------------------------------------------------------------------
-- Step #7.4: Creating VRandomizedActive
-- --------------------------------------------------------------------------------
CREATE VIEW VRandomizedActive
AS
	SELECT COUNT(intRandomCodeID) AS NumberActiveCodes
	FROM VRandomizedPatients
	WHERE intStudyID = 2
	AND strTreatment = 'A'
GO

-- --------------------------------------------------------------------------------
-- Step #7.4: Creating VRandomCodes
-- --------------------------------------------------------------------------------
CREATE VIEW VRandomCodes
AS
	SELECT intRandomCodeID, intRandomCode, intStudyID, strTreatment, blnAvailable
	FROM TRandomCodes
GO
-- --------------------------------------------------------------------------------
-- Step #8: Creating uspScreenPatient
-- --------------------------------------------------------------------------------

CREATE PROCEDURE uspScreenPatient
	@intPatientNumber	AS INTEGER OUTPUT
   ,@intSiteID			AS INTEGER
   ,@dtmDateofBirth		AS DATE
   ,@intGenderID		AS INTEGER
   ,@intWeight			AS INTEGER
   ,@dtmDateofVisit		AS DATE
AS
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error
BEGIN TRANSACTION
	DECLARE @intPatientID AS INTEGER
	EXECUTE uspAddPatient @intPatientNumber OUTPUT, @intSiteID, @dtmDateofBirth, @intGenderID, @intWeight
	SET @intPatientID = (SELECT MAX(intPatientID) FROM TPatients)
	INSERT INTO TVisits (intPatientID, dtmDateofVisit, intVisitTypeID)
	VALUES (@intPatientID, @dtmDateofVisit, 1)
COMMIT TRANSACTION
GO

-- --------------------------------------------------------------------------------
-- Step #9: Creating uspWithdrawPatient
-- --------------------------------------------------------------------------------

CREATE PROCEDURE uspWithdrawPatient
	@intPatientNumber			AS INTEGER
   ,@intWithdrawReasonID		AS INTEGER
   ,@dtmDateofVisit				AS DATE
AS
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error
BEGIN TRANSACTION
	DECLARE @dtmPrevVisit AS DATE
	DECLARE @intPatientID AS INTEGER
	SET @intPatientID = (SELECT intPatientID FROM TPatients WHERE intPatientNumber = @intPatientNumber)
	BEGIN
		DECLARE GetPrevDate CURSOR LOCAL FOR
		SELECT MAX(dtmDateofVisit) AS PrevDate FROM VVisits
		WHERE intPatientNumber = @intPatientNumber

	OPEN GetPrevDate
	FETCH FROM GetPrevDate
	INTO @dtmPrevVisit
	CLOSE GetPrevDate
	END

	IF @dtmDateofVisit < @dtmPrevVisit
		PRINT 'ERROR AND ROLLED BACK: Current Visit Date is older than Previous Visit'
	ELSE
		INSERT INTO TVisits (intPatientID, dtmDateofVisit, intVisitTypeID, intWithdrawReasonID)
		VALUES (@intPatientID, @dtmDateofVisit, 3, @intWithdrawReasonID)

COMMIT TRANSACTION
GO

-- --------------------------------------------------------------------------------
-- Step #10.2: Creating uspRandomizedNumber
-- --------------------------------------------------------------------------------

CREATE PROCEDURE uspRandomizedNumber
	@intRandomizedCodeID	AS INTEGER OUTPUT
AS
BEGIN
	DECLARE @intRandomizedPlacebo	AS INTEGER 
	DECLARE @intRandomizedActive	AS INTEGER 
	DECLARE @intDifference			AS INTEGER
	SET @intRandomizedPlacebo = (SELECT * FROM VRandomizedPlacebo)
	SET @intRandomizedActive  = (SELECT * FROM VRandomizedActive)
	SET @intDifference = ABS(@intRandomizedActive - @intRandomizedPlacebo)
	IF @intDifference < 2
		BEGIN
		DECLARE @intRandom	AS INTEGER
		SET @intRandom = (SELECT RAND()*(5-1));
		IF @intRandom >= 3
			SET @intRandomizedCodeID = (SELECT * FROM VStudyTwoNextPlaceboCode)
		ELSE
			SET @intRandomizedCodeID = (SELECT * FROM VStudyTwoNextActiveCode)
		END
	ELSE
		IF @intRandomizedActive > @intRandomizedPlacebo
			SET @intRandomizedCodeID = (SELECT * FROM VStudyTwoNextPlaceboCode)
		ELSE
			SET @intRandomizedCodeID = (SELECT * FROM VStudyTwoNextActiveCode)
END
GO

-- --------------------------------------------------------------------------------
-- Step #10.2: Creating uspAssignDrugkit
-- --------------------------------------------------------------------------------
CREATE PROCEDURE uspAssignDrugKit
	@intPatientID	AS INTEGER
   ,@intSiteID		AS INTEGER
   ,@strTreatment	AS VARCHAR(250)
AS
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error
BEGIN TRANSACTION
	DECLARE @intVisitID	  AS INTEGER
	BEGIN
		DECLARE GetintVisitID CURSOR LOCAL FOR
		SELECT MAX(intVisitID) FROM VVisits
		WHERE intPatientID = @intPatientID

		OPEN GetintVisitID
		FETCH FROM GetintVisitID
		INTO @intVisitID
		CLOSE GetintVisitID
	END

	UPDATE TDrugKits
	SET intVisitID = @intVisitID
	WHERE intDrugKitID  IN (SELECT MIN(intDrugKitID) FROM TDrugKits
						    WHERE strTreatment = @strTreatment
							AND intSiteID = @intSiteID)
COMMIT TRANSACTION
GO
-- --------------------------------------------------------------------------------
-- Step #10.3: Creating uspRandomizePatient
-- --------------------------------------------------------------------------------

CREATE PROCEDURE uspRandomizePatient
	@intPatientNumber	  AS INTEGER
   ,@intSiteNumber		  AS INTEGER

AS
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error
BEGIN TRANSACTION
	DECLARE @intStudyID				AS INTEGER
	DECLARE @intPatientID			AS INTEGER
	DECLARE @intSiteID				AS INTEGER
	DECLARE @intRandomizedCodeID	AS INTEGER
	DECLARE @intDrugKitID			AS INTEGER
	DECLARE @dtmCurrentDate			AS DATE
	DECLARE @strTreatment			AS VARCHAR(250)
	SET @dtmCurrentDate = GETDATE()


	BEGIN
		DECLARE GetStudyID CURSOR LOCAL FOR
		SELECT intStudyID FROM VSitePatients
		WHERE intPatientNumber = @intPatientNumber

		OPEN GetStudyID
		FETCH FROM GetStudyID
		INTO @intStudyID
		CLOSE GetStudyID
	END

	BEGIN
		DECLARE GetintPatientID CURSOR LOCAL FOR
		SELECT intPatientID FROM VSitePatients
		WHERE intPatientNumber = @intPatientNumber

		OPEN GetintPatientID
		FETCH FROM GetintPatientID
		INTO @intPatientID
		CLOSE GetintPatientID
	END

	BEGIN
		DECLARE GetSiteID CURSOR LOCAL FOR
		SELECT intSiteID FROM VSitePatients
		WHERE intSiteNumber = @intSiteNumber

		OPEN GetSiteID
		FETCH FROM GetSiteID
		INTO @intSiteID
		CLOSE GetSiteID
	END

	IF @intStudyID = 1
		BEGIN
			SET @intRandomizedCodeID = (SELECT Next_Code_Study_One FROM VStudyOneNextCode)
			SET @strTreatment = (SELECT strTreatment FROM VRandomCodes WHERE intRandomCode = @intRandomizedCodeID)
			UPDATE TRandomCodes
			SET blnAvailable = 'F'
			WHERE intRandomCodeID = @intRandomizedCodeID
		END
	ELSE
			EXECUTE uspRandomizedNumber @intRandomizedCodeID OUTPUT
			SET @strTreatment = (SELECT strTreatment FROM VRandomCodes WHERE intRandomCodeID = @intRandomizedCodeID)			UPDATE TRandomCodes
			SET blnAvailable = 'F'
			WHERE intRandomCodeID = @intRandomizedCodeID
	

	INSERT INTO TVisits (intPatientID, dtmDateofVisit, intVisitTypeID)
	VALUES (@intPatientID, @dtmCurrentDate, 2)

	UPDATE TPatients
	SET intRandomCodeID = @intRandomizedCodeID
	WHERE intPatientID = @intPatientID

	EXECUTE uspAssignDrugKit @intPatientID, @intSiteID, @strTreatment
		
COMMIT TRANSACTION
GO
