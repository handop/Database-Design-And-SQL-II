-- --------------------------------------------------------------------------------
-- Name: Oliver Hand
-- Class: IT-112
-- Abstract: Final Project
-- --------------------------------------------------------------------------------

-- --------------------------------------------------------------------------------
-- Options
-- --------------------------------------------------------------------------------
USE dbSQL1;     -- Get out of the master database
SET NOCOUNT ON; -- Report only errors

-- --------------------------------------------------------------------------------
-- Screening Patients
-- --------------------------------------------------------------------------------
DECLARE @intPatientNumber AS INTEGER = 0
--Screening Study One Patients
EXECUTE uspScreenPatient @intPatientNumber OUTPUT, 1, '1/15/2000', 1,  170, '11/18/2022'
EXECUTE uspScreenPatient @intPatientNumber OUTPUT, 2, '2/15/1998', 2,  290, '11/18/2022'
EXECUTE uspScreenPatient @intPatientNumber OUTPUT, 3, '3/15/2005', 2,  290, '11/18/2022'
EXECUTE uspScreenPatient @intPatientNumber OUTPUT, 2, '4/15/1976', 1,  690, '11/18/2022'
EXECUTE uspScreenPatient @intPatientNumber OUTPUT, 1, '5/15/1234', 1,  170, '11/18/2022'
EXECUTE uspScreenPatient @intPatientNumber OUTPUT, 2, '6/15/1903', 2,  290, '11/18/2022'
EXECUTE uspScreenPatient @intPatientNumber OUTPUT, 3, '1/15/1804', 2,  290, '11/18/2022'
EXECUTE uspScreenPatient @intPatientNumber OUTPUT, 2, '1/15/2000', 1,  690, '11/18/2022'

--Screening Study Two Patients
EXECUTE uspScreenPatient @intPatientNumber OUTPUT, 4, '1/15/2000', 1,  170, '11/18/2022'
EXECUTE uspScreenPatient @intPatientNumber OUTPUT, 5, '1/15/2000', 2,  290, '11/18/2022'
EXECUTE uspScreenPatient @intPatientNumber OUTPUT, 6, '1/15/2000', 2,  290, '11/18/2022'
EXECUTE uspScreenPatient @intPatientNumber OUTPUT, 5, '1/15/2000', 1,  690, '11/18/2022'
EXECUTE uspScreenPatient @intPatientNumber OUTPUT, 4, '1/15/2000', 1,  170, '11/18/2022'
EXECUTE uspScreenPatient @intPatientNumber OUTPUT, 5, '1/15/2000', 2,  290, '11/18/2022'
EXECUTE uspScreenPatient @intPatientNumber OUTPUT, 6, '1/15/2000', 2,  290, '11/18/2022'
EXECUTE uspScreenPatient @intPatientNumber OUTPUT, 4, '1/15/2000', 1,  690, '11/18/2022'

-- --------------------------------------------------------------------------------
-- Randomizing Patients
-- --------------------------------------------------------------------------------
--Randomizing Study One Patients
EXECUTE uspRandomizePatient 101002, 101
EXECUTE uspRandomizePatient 111004, 111
EXECUTE uspRandomizePatient 121001, 121
EXECUTE uspRandomizePatient 111003, 111
EXECUTE uspRandomizePatient 101001, 101
--Randomizing Study Two Patients
EXECUTE uspRandomizePatient 511001, 511
EXECUTE uspRandomizePatient 501002, 501
EXECUTE uspRandomizePatient 521002, 521
EXECUTE uspRandomizePatient 501003, 501
EXECUTE uspRandomizePatient 521001, 521
-- --------------------------------------------------------------------------------
-- Withdrawing Patients
-- --------------------------------------------------------------------------------
--Withdrawing Study One Patients
EXECUTE uspWithdrawPatient 101001, 6, '12/24/2023'
EXECUTE uspWithdrawPatient 111003, 3, '12/24/2023'
EXECUTE uspWithdrawPatient 111002, 2, '11/19/2022'
EXECUTE uspWithdrawPatient 121002, 1, '11/21/2022'

--Withdrawing Study Two Patients
EXECUTE uspWithdrawPatient 511001, 1, '12/24/2023'
EXECUTE uspWithdrawPatient 501003, 4, '12/24/2023'
EXECUTE uspWithdrawPatient 501001, 1, '11/19/2022'
EXECUTE uspWithdrawPatient 511002, 5, '11/21/2022'
